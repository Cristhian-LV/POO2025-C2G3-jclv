package pe.edu.upeu.asistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsistenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
